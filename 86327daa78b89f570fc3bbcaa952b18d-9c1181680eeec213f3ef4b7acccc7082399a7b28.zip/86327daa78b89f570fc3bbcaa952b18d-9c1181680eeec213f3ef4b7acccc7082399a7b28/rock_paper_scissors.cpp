# include <iostream>
# include <stdlib.h>

int main() {
/*
Rock Paper Scissors Lizard Spock
(The Big Bang Theory)
*/

//live long and prosper

srand (time(NULL));  //creat a random number
  
int computer = rand() % 3 + 1;  //assure the scope's of the random number among 1-3

int user = 0;

std::cout << "====================\n";
std::cout << "rock paper scissors!\n";
std::cout << "====================\n";

std::cout << "1) ✊\n";
std::cout << "2) ✋\n";
std::cout << "3) ✌️\n";

std::cout << "shoot! ";

std::cin>>user;

if (computer == user){

 std::cout<<"Tie!\n";
}

else if(((computer == 1) && (user == 2)) || ((computer == 2) && (user == 3)) || ((computer == 3) && (user == 1))){

  std::cout <<"You win!\n";
}

else {

  std::cout <<"You lost!\n";
}


}